package com.example.bazarhazar;

public class services {
    public String services, description, url1, url2, url3;

    public services() {

    }

    public services(String services, String description, String url1, String url2, String url3) {
        this.services = services;
        this.description = description;
        this.url1 = url1;
        this.url2 = url2;
        this.url3 = url3;
    }
}




