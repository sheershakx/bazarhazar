package com.example.bazarhazar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.view.View;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class userlog extends AppCompatActivity {
    private FirebaseStorage firebaseStorage;
    private DatabaseReference databaseReference;
    private StorageReference storageReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        storageReference =FirebaseStorage.getInstance().getReference("images/");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlog);
        getSupportActionBar().setTitle("Activity Log");
    }




}
