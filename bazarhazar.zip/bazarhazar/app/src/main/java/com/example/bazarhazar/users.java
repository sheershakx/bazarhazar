package com.example.bazarhazar;

public class users {
    public String companyname,contactperson,email,phone,password,province,district,city;

    public users(){

    }

    public users(String companyname, String contactperson, String email,String phone,String password,String province,String district,String city) {
        this.companyname = companyname;
        this.contactperson = contactperson;
        this.email = email;
        this.phone=phone;
        this.password=password;
        this.province = province;
        this.district = district;
        this.city = city;
    }
}


