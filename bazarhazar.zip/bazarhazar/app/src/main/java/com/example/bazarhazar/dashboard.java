package com.example.bazarhazar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.internal.Util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.PublicKey;
import java.util.UUID;

public class dashboard extends AppCompatActivity{
    private Button btn1,btn2,btn3,save;
    private Uri filepath1,filepath2,filepath3;
    private FirebaseStorage storage;
    private StorageReference storageReference;
    EditText serv,desc;
    DatabaseReference databaseReference;
    FirebaseAuth firebaseAuth;
    String uri1,uri2,uri3;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        databaseReference=FirebaseDatabase.getInstance().getReference("companyinformation");
        firebaseAuth=FirebaseAuth.getInstance();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        getSupportActionBar().setTitle("Dashboard");

        btn1=(Button)findViewById(R.id.btn_choose1);
        btn2=(Button)findViewById(R.id.btn_choose2);
        btn3=(Button)findViewById(R.id.btn_choose3);
        save=(Button)findViewById(R.id.btn_save);
        storage=FirebaseStorage.getInstance();
        storageReference=storage.getReference();


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseImage1();

            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseImage2();

            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseImage3();

            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadImage();

            }
        });




            }
/**
    private void uploadinfo() {

        serv=(EditText)findViewById(R.id.txt_services);
        final String services=serv.getText().toString();

        desc=(EditText)findViewById(R.id.txt_description);
        final String description=desc.getText().toString();

        EditText eml=(EditText)findViewById(R.id.id_email);
        String email=eml.getText().toString();

        if (TextUtils.isEmpty(services)) {
            Toast.makeText(dashboard.this, "Please Enter Services Provided", Toast.LENGTH_SHORT).show();
        }
        if (TextUtils.isEmpty(description)) {
            Toast.makeText(dashboard.this, "Please Enter Description", Toast.LENGTH_SHORT).show();
        }



        firebaseAuth.createUserWithEmailAndPassword(email,email)
                .addOnCompleteListener(dashboard.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            services information=new services (
                                    services,
                                    description
                            );
                            FirebaseDatabase.getInstance().getReference("companyservice")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(information).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    //toast message
                                    Toast.makeText(getApplicationContext(),"Your company information is saved into Bazarhazar database",Toast.LENGTH_LONG).show();




                                }
                            });



                        } else {
                            Toast.makeText(getApplicationContext(),"Sorry, saving failed..",Toast.LENGTH_LONG).show();
                        }

                        // ...
                    }
                });




    }    **/

    private void chooseImage3() {
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Image"),3);
    }

    private void chooseImage2() {
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Image"),2);
    }

    private void chooseImage1() {
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Image"),1);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==1 && resultCode==RESULT_OK && data!=null){

            filepath1 =data.getData();
            try {
                Bitmap bitmap=MediaStore.Images.Media.getBitmap(getContentResolver(),filepath1);
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
        if(requestCode==2 && resultCode==RESULT_OK && data!=null){

            filepath2 =data.getData();
            try {
                Bitmap bitmap=MediaStore.Images.Media.getBitmap(getContentResolver(),filepath2);
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
        if(requestCode==3 && resultCode==RESULT_OK && data!=null){

            filepath3 =data.getData();
            try {
                Bitmap bitmap=MediaStore.Images.Media.getBitmap(getContentResolver(),filepath3);
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
    }

    private void uploadImage() {

        if(filepath1!=null || filepath2!=null || filepath3!=null){
            final ProgressDialog progressDialog=new ProgressDialog(this);
            progressDialog.setTitle("Uploading........");

            StorageReference reference=storageReference.child("images/"+UUID.randomUUID().toString());
            reference.putFile(filepath1)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();
                            Uri uploaduri=taskSnapshot.getUploadSessionUri();
                            String url1=uploaduri.toString();
                            uri1=url1;


                            Toast.makeText(dashboard.this,"Image 1 uploaded", Toast.LENGTH_SHORT).show();

                        }
                    });
            StorageReference reference1=storageReference.child("images/"+UUID.randomUUID().toString());
            reference1.putFile(filepath2)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();
                            Uri uploaduri=taskSnapshot.getUploadSessionUri();
                            String url2=uploaduri.toString();
                            uri2=url2;
                            Toast.makeText(dashboard.this, "Image 2 Uploaded", Toast.LENGTH_SHORT).show();

                        }
                    });
            StorageReference reference2=storageReference.child("images/" +UUID.randomUUID().toString());
            reference2.putFile(filepath3)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();
                            Uri uploaduri=taskSnapshot.getUploadSessionUri();
                            String url3=uploaduri.toString();
                            uri3=url3;
                            Toast.makeText(dashboard.this, "Image 3 Uploaded", Toast.LENGTH_SHORT).show();


                        }
                    })

                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress=(100.0*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                            progressDialog.setMessage("Uploaded"+(int)progress+"%");

                        }
                    });

        }
        serv=(EditText)findViewById(R.id.txt_services);
        final String servicess=serv.getText().toString();

        desc=(EditText)findViewById(R.id.txt_description);
        final String description=desc.getText().toString();


        if (TextUtils.isEmpty(servicess)) {
            Toast.makeText(dashboard.this, "Please Enter Services Provided", Toast.LENGTH_SHORT).show();
        }
        if (TextUtils.isEmpty(description)) {
            Toast.makeText(dashboard.this, "Please Enter Description", Toast.LENGTH_SHORT).show();
        }

        String id=databaseReference.push().getKey();
        String companyname="helloworld";
        services serv=new services(servicess,description,uri1,uri2,uri3);
        databaseReference.child(companyname).setValue(serv);
    }
    



}
